$(document).ready(function () {
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.kd-scrollToTop').fadeIn();
        } else {
            $('.kd-scrollToTop').fadeOut();
        }
    });

    $('.kd-scrollToTop').click(function () {
        $("html, body").animate({
            scrollTop: 0
        },600);
        return false;
    });

});
$(document).ready(function() {
$(".scrollToDown").click(function() {
     $('html, body').animate({
         scrollTop: $("#reservenow").offset().top
     }, 600);
 });
});

       
       