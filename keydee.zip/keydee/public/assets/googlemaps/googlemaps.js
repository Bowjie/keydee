  function initMap(){
    var googlemap = {lat:14.573332, lng:121.091400};
    
    var map = new google.maps.Map(document.getElementsByID('map'), {
      zoom: 8,
      center: googlemap
    });

    var marker = new google.maps.Market({
      position: googlemap,
      map: map
    })
  }