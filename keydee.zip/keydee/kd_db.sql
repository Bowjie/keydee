-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2018 at 02:24 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kdt&t`
--
CREATE Database kd_db;
USE kd_db;
-- --------------------------------------------------------

--
-- Table structure for table `kd_chinapack`
--

CREATE TABLE `kd_chinapack` (
  `pack_id` int(11) NOT NULL,
  `pack_name` varchar(30) DEFAULT NULL,
  `pack_country` varchar(45) DEFAULT NULL,
  `pack_img` varchar(35) DEFAULT NULL,
  `pack_price` varchar(15) DEFAULT NULL,
  `size` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kd_chinapack`
--

INSERT INTO `kd_chinapack` (`pack_id`, `pack_name`, `pack_country`, `pack_img`, `pack_price`, `size`) VALUES
(1, 'Shanghai', 'China', 'public/packages/shanghai.jpg', '10,000.00', 'a'),
(3, 'Macau', 'China', 'public/packages/macau.jpg', '10,000.00', 'a'),
(4, 'Hong Kong', 'China', 'public/packages/hong_kong.jpg', '10,000.00', 'b');

-- --------------------------------------------------------

--
-- Table structure for table `kd_indopack`
--

CREATE TABLE `kd_indopack` (
  `pack_id` int(11) NOT NULL,
  `pack_name` varchar(30) DEFAULT NULL,
  `pack_country` varchar(45) DEFAULT NULL,
  `pack_img` varchar(35) DEFAULT NULL,
  `pack_price` varchar(15) DEFAULT NULL,
  `size` varchar(2) DEFAULT NULL,
  `filename` char(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kd_indopack`
--

INSERT INTO `kd_indopack` (`pack_id`, `pack_name`, `pack_country`, `pack_img`, `pack_price`, `size`, `filename`) VALUES
(0, '3D2N Bali Indonesia', 'Indonesia', 'public/packages/bali.jpg', '3,250.00', 'a', 'bali');

-- --------------------------------------------------------

--
-- Table structure for table `kd_philpack`
--

CREATE TABLE `kd_philpack` (
  `pack_id` int(11) NOT NULL,
  `pack_name` varchar(30) NOT NULL,
  `pack_country` varchar(45) NOT NULL,
  `pack_img` varchar(35) NOT NULL,
  `pack_price` varchar(15) NOT NULL,
  `size` char(2) NOT NULL,
  `filename` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kd_philpack`
--

INSERT INTO `kd_philpack` (`pack_id`, `pack_name`, `pack_country`, `pack_img`, `pack_price`, `size`, `filename`) VALUES
(1, 'Bacolod Trip', 'Negros Island, Philippines', 'public/packages/bacolod.jpg', '6,000.00', 'a', 'bacolod'),
(2, 'Baguio City', 'Philippines', 'public/packages/baguio.jpg', '10,000.00', 'a', 'baguio'),
(3, 'Batanes Province', 'Philippines', 'public/packages/batanes.jpg', '8,000.00', 'a', 'batanes'),
(4, 'Bohol City', 'Central Visayas, Philippines', 'public/packages/bohol.jpg', '14,000.00', 'a', 'bohol'),
(5, 'Bolinao', 'Philippines', 'public/packages/bolinao.jpg', '10,000.00', 'a', 'bolinao'),
(6, 'Boracay Island', 'Philippines', 'public/packages/boracay.jpg', '2,050.00', 'b', 'boracay'),
(7, 'Cabongaoan Beach', 'Philippines', 'public/packages/cabangaoan.jpg', '10,000.00', 'a', 'cabongaoan'),
(8, 'Calaguas', 'Philippines', 'public/packages/calaguas.jpg', '10,000.00', 'b', 'calaguas'),
(9, 'Camiguin', 'Philippines', 'public/packages/camiguin.jpg', '10,000.00', 'b', 'camiguin'),
(10, 'Caramoan', 'Philippines', 'public/packages/caramoan.jpg', '10,000.00', 'a', 'caramoan'),
(11, 'Cebu', 'Philippines', 'public/packages/cebu.jpg', '2,350.00', 'b', 'cebu'),
(13, 'Davao City', 'Mindanao, Philippines', 'public/packages/davao.jpg', '10,000.00', 'b', 'davao'),
(14, 'El Nido', 'Palawan, Philippines', 'public/packages/el_nido.jpg', '15,000.00', 'a', 'elnido'),
(15, 'Hundred Islands', 'Pangasinan, Philippines', 'public/packages/hundred_islands.jpg', '10,000.00', 'b', 'hundredislands'),
(16, 'Ilocos', 'Philippines', 'public/packages/ilocos.jpg', '10,000.00', 'b', 'ilocos'),
(17, 'La Union', 'Philippines', 'public/packages/la_union.jpg', '10,000.00', 'a', 'launion'),
(18, 'Malapascua', 'Philippines', 'public/packages/malapascua.jpg', '10,000.00', 'a', 'malapascua'),
(19, 'Maldrives', 'Philippines', 'public/packages/maldives.jpg', '10,000.00', 'a', 'maldives'),
(20, 'Phuket Province', 'Philippines', 'public/packages/phuket.jpg', '10,000.00', 'a', 'phuket'),
(21, 'Puerto Princesa', 'Palawan Island, Philippines', 'public/packages/puerto_princesa.jpg', '10,000.00', 'a', 'puerto'),
(22, 'Sagada', 'Philippines', 'public/packages/sagada.jpg', '10.000.00', 'b', 'sagada'),
(23, 'Siargao Island', 'Philippines', 'public/packages/siargao.jpg', '10,000.00', 'a', 'siargao'),
(24, '3D2N Bangkok', 'Philippines', 'public/packages/bangkok.jpg', '3,950.00', 'a', 'bangkok'),
(25, '3D2N Batanes Philippines', 'Philippines', 'public/packages/batanes.jpg', '1,750.00', 'a', 'batanes'),
(26, '3D2N Coron Package', 'Philippines', 'public/packages/coron.jpg', '2,400.00', 'a', 'coron');

-- --------------------------------------------------------

--
-- Table structure for table `kd_popular_images`
--

CREATE TABLE `kd_popular_images` (
  `kd_id` int(11) NOT NULL,
  `kd_name` varchar(30) NOT NULL,
  `kd_country` varchar(45) NOT NULL,
  `kd_img` varchar(27) NOT NULL,
  `kd_price` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kd_popular_images`
--

INSERT INTO `kd_popular_images` (`kd_id`, `kd_name`, `kd_country`, `kd_img`, `kd_price`) VALUES
(1, 'Bacolod Trip', 'Negros Island, Philippines', 'public/packages/bacolod.jpg', '6,000.00'),
(2, 'Baguio City', 'Philippines', 'public/packages/baguio.jpg', '10,000.00'),
(3, 'Macau', 'Macau', 'public/packages/macau.jpg', '12,000.00');

-- --------------------------------------------------------

--
-- Table structure for table `kd_taiwanpack`
--

CREATE TABLE `kd_taiwanpack` (
  `pack_id` int(11) NOT NULL,
  `pack_name` varchar(30) DEFAULT NULL,
  `pack_country` varchar(45) DEFAULT NULL,
  `pack_img` varchar(35) DEFAULT NULL,
  `pack_price` varchar(15) DEFAULT NULL,
  `size` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kd_thaipack`
--

CREATE TABLE `kd_thaipack` (
  `pack_id` int(11) NOT NULL,
  `pack_name` varchar(30) DEFAULT NULL,
  `pack_country` varchar(45) DEFAULT NULL,
  `pack_img` varchar(35) DEFAULT NULL,
  `pack_price` varchar(15) DEFAULT NULL,
  `size` varchar(2) DEFAULT NULL,
  `filename` char(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kd_thaipack`
--

INSERT INTO `kd_thaipack` (`pack_id`, `pack_name`, `pack_country`, `pack_img`, `pack_price`, `size`, `filename`) VALUES
(0, '3D2N Bangkok Thailand', 'Thailand', 'public/packages/bangkok.jpg', '3,950', 'a', 'bangkok');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kd_chinapack`
--
ALTER TABLE `kd_chinapack`
  ADD PRIMARY KEY (`pack_id`);

--
-- Indexes for table `kd_indopack`
--
ALTER TABLE `kd_indopack`
  ADD PRIMARY KEY (`pack_id`);

--
-- Indexes for table `kd_philpack`
--
ALTER TABLE `kd_philpack`
  ADD PRIMARY KEY (`pack_id`);

--
-- Indexes for table `kd_popular_images`
--
ALTER TABLE `kd_popular_images`
  ADD PRIMARY KEY (`kd_id`);

--
-- Indexes for table `kd_taiwanpack`
--
ALTER TABLE `kd_taiwanpack`
  ADD PRIMARY KEY (`pack_id`);

--
-- Indexes for table `kd_thaipack`
--
ALTER TABLE `kd_thaipack`
  ADD PRIMARY KEY (`pack_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kd_chinapack`
--
ALTER TABLE `kd_chinapack`
  MODIFY `pack_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `kd_philpack`
--
ALTER TABLE `kd_philpack`
  MODIFY `pack_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `kd_popular_images`
--
ALTER TABLE `kd_popular_images`
  MODIFY `kd_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `kd_taiwanpack`
--
ALTER TABLE `kd_taiwanpack`
  MODIFY `pack_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
