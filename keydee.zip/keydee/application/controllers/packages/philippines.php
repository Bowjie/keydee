<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class philippines extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	function index()
	{
		$this->load->model('allpackModel');
		$data['getPhil'] = $this->allpackModel->getPhil();

		$this->load->view('PagesView/header');
		$this->load->view('PagesView/packages/philippines/PhilippinesView', $data);
		$this->load->view('PagesView/footer');
	}
	function bacolod()
	{
		$this->load->view('PagesView/header');
		$this->load->view('PagesView/packages/philippines/bacolod');
		$this->load->view('PagesView/footer');
	}
	function batanes()
	{
		$this->load->view('PagesView/header');
		$this->load->view('PagesView/packages/philippines/batanes');
		$this->load->view('PagesView/footer');
	}
	function boracay()
	{
		$this->load->view('PagesView/header');
		$this->load->view('PagesView/packages/philippines/boracay');
		$this->load->view('PagesView/footer');
	}
	function cebu()
	{
		$this->load->view('PagesView/header');
		$this->load->view('PagesView/packages/philippines/cebu');
		$this->load->view('PagesView/footer');
	}
	function coron()
	{
		$this->load->view('PagesView/header');
		$this->load->view('PagesView/packages/philippines/coron');
		$this->load->view('PagesView/footer');
	}
}