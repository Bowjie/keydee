<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class thailand extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	function index()
	{
		$this->load->model('allpackModel');
		$data['getThai'] = $this->allpackModel->getThai();

		$this->load->view('PagesView/header');
		$this->load->view('PagesView/packages/thailand/ThailandView', $data);
		$this->load->view('PagesView/footer');
	}
	function bangkok()
	{
		$this->load->view('PagesView/header');
		$this->load->view('PagesView/packages/thailand/bangkok');
		$this->load->view('PagesView/footer');
	}
}