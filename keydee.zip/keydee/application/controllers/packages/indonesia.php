<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class indonesia extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	function index()
	{
		$this->load->model('allpackModel');
		$data['getIndo'] = $this->allpackModel->getIndo();

		$this->load->view('PagesView/header');
		$this->load->view('PagesView/packages/indonesia/IndonesiaView', $data);
		$this->load->view('PagesView/footer');
	}
	function bali()
	{
		$this->load->view('PagesView/header');
		$this->load->view('PagesView/packages/indonesia/bali');
		$this->load->view('PagesView/footer');
	}
}