<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class admin extends CI_Controller
{
	public function __construct(){
		parent::__construct();
		$this->load->helper('url','form','file');
		$this->load->database();
	}
	public function index(){
		$this->load->view('AdminView/uploadView');
	}
	public function upload_package(){

		$config['upload_path'] = './public/packages/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['overwrite'] = TRUE;
		$this->load->library('upload', $config);

		$upload_files = $this->upload->do_upload('img');

		if($upload_files){

			$this->load->model('insertPackageModel');

			$filename = $this->upload->data('file_name');
			$filepath = 'public/packages/'.$filename;

			$data = array(
			'pack_name' =>	$this->input->post('pname'),
			'filename' =>	$this->input->post('filename'),
			'pack_country' =>	$this->input->post('cntry'),
			'pack_img' =>	$filepath,
			'pack_price' =>	$this->input->post('price'),
			'size' =>	$this->input->post('size')
		);
			if ($data['pack_country'] == 'Philippines') {
				$this->insertPackageModel->insert_package_philippines($data);
		redirect(site_url('admin/inserted'));
			}
			elseif ($data['pack_country'] == 'China') {
				$this->insertPackageModel->insert_package_china($data);
		redirect(site_url('admin/inserted'));
			}
			elseif ($data['pack_country'] == 'Taiwan') {
				$this->insertPackageModel->insert_package_taiwan($data);
		redirect(site_url('admin/inserted'));
			}
			elseif ($data['pack_country'] == 'Indonesia') {
				$this->insertPackageModel->insert_package_indonesia($data);
		redirect(site_url('admin/inserted'));
			}elseif ($data['pack_country'] == 'Thailand') {
				$this->insertPackageModel->insert_package_thailand($data);
		redirect(site_url('admin/inserted'));
			}
		}
		else
		{
			redirect(site_url('admin/error'));
		}
		
	}

	public function inserted(){
		$this->index();
	}
	public function error(){
		$this->index();
	}
}