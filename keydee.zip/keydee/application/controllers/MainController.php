<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MainController extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	function index(){

		$this->load->model('fetchModel');
		$data['get_data'] = $this->fetchModel->get_data();

		$this->load->view('PagesView/header');
		$this->load->view('PagesView/main/HomeView', $data);
		$this->load->view('PagesView/footer');
	}
}