<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class about extends CI_Controller
{
	function index(){
		$this->load->view('PagesView/header');
		$this->load->view('PagesView/main/AboutView');
		$this->load->view('PagesView/footer');
	}
}