<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class allpackages extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	function index()
	{
		// $this->load->model('allpackModel');
		// $data['getThai'] = $this->allpackModel->getThai();

		// $this->load->view('PagesView/header');
		// $this->load->view('PagesView/packages/allpackages', $data);
		// $this->load->view('PagesView/footer');
		echo "<h1 style='padding-right: 15px;padding-left:15px;padding-top:15px;'>Under Maintenance</h1>";
	}
}