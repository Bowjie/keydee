<!DOCTYPE html>
<html>
<head>
	<title>Update Files</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
</head>
<style>
	.container{
		padding: 3rem 120px;
	}
	.input-form{
		margin: 15px;
		margin-left: 0px;
		margin-top: 0px;
	}
	.mb-1{
		margin-bottom: 30px;
	}
</style>
<body>
	<div class="container">
		<form method="post" action="<?=site_url('admin/upload_package');?>" enctype="multipart/form-data">
			<h2 class="input-form mb-1">Upload Package</h2>
			<div class="input-form">
				<?php 
        if($this->uri->segment(2) == 'inserted'){
         ?>
         <p>INSERTED</p>
        <?php } 
        elseif ($this->uri->segment(2) == 'error') {
        	echo "<p>NOT INSERTED</p>";
        }

        ?>
			</div>
			<label>Package Name</label>
			<div class="input-form"><input type="text" name="pname" placeholder="Package name"></div>
			<label>File Name</label>
			<div class="input-form"><input type="text" name="filename" placeholder="File name"></div>
			<label>Country</label>
			<div class="input-form">
				<select name="cntry">
					<option value="Philippines">Philippines</option>
					<option value="China">China</option>
					<option value="Taiwan">Taiwan</option>
					<option value="Indonesia">Indonesia</option>
					<option value="Thailand">Thailand</option>
				</select>
			</div>
			<label>Package Price</label>
			<div class="input-form"><input type="text" name="price" placeholder="Price"></div>
			<label>Package Size</label>
			<div class="input-form">
				<select name="size" style="width: 100px;">
					<option value="a"> A </option>
					<option value="b"> B </option>
				</select>
			</div>
			<label>Update Image</label>
			<div class="input-form"><input type="file" name="img"></div>
			<input type="submit" name="submit" value="upload">
		</form>
	</div>
</body>
</html>