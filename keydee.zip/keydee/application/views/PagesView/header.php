<!DOCTYPE html>
<html>
<head>
    <title>KD Travels & Tours</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="HTML,CSS,Javscript">
    <meta name="description" content="KD travel agency">
    <link rel="stylesheet" href="<?=base_url('public/dist/css/bootstrap.min.css');?>">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css" />
    <!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans"> -->
    <link rel="stylesheet" href="<?=base_url('public/assets/kdstyle.css')?>">
    <link rel="stylesheet" href="<?=base_url('public/assets/packages.css')?>">
    <link rel="stylesheet" type="text/css" href="<?=base_url('public/assets/loader.css');?>">
</head>
<body>
     <nav class="navbar navbar-expand-lg" id="navbarHide">
      <div class="container">
        <a class="navbar-brand" href="<?=base_url()?>">
        <div class="kdlogo" alt="KD Logo">
            <div class="ki">K </div>
            <i class="fas fa-map-marker-alt"></i> 
            <div class="di">D Travel & Tours</div>
        </div></a>
        <div class="custom-spacing"></div>
        <div class="navbar-toggler" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <i class="fas fa-bars"></i>
        </div>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">  
            <li class="nav-item">
              <a class="nav-link" href="<?=site_url('services')?>">Services</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Packages
                </a>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                    <a class="dropdown-item" href="<?=site_url('packages')?>">See all packages </a>
                    <a class="dropdown-item" href="<?=site_url('packages/philippines')?>">Philippines <div class="text-muted" style="display: inline-block;">(10)</div></a>
                    <a class="dropdown-item" href="#">South Asia <div class="text-muted d-inline">(10)</div></a>
                    <a class="dropdown-item" href="#">Tokyo, Japan <div class="text-muted d-inline" >(10)</div></a>
                    <a class="dropdown-item" href="#">China <div class="text-muted d-inline">(10)</div></a>
                    <a class="dropdown-item" href="#">Singapore <div class="text-muted d-inline" >(10)</div></a>
                    <a class="dropdown-item" href="#">Taiwan <div class="text-muted d-inline" >(10)</div></a>
                    <a class="dropdown-item" href="#">Cambodia <div class="text-muted d-inline" >(10)</div></a>
                    <a class="dropdown-item" href="#">Malaysia <div class="text-muted d-inline" >(10)</div></a>
                    <a class="dropdown-item" href="<?=site_url('packages/indonesia');?>">Indonesia <div class="text-muted d-inline">(10)</div></a>
                    <a class="dropdown-item" href="<?=site_url('packages/thailand');?>">Thailand <div class="text-muted d-inline">(10)</div></a>
                </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?=site_url('about')?>">Travel With Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?=site_url('contact')?>">Contact</a>
            </li>
          </ul>
       <!--    <div class="form-inline my-2 my-lg-0 ml-auto">
     
      <button class="btn btn-custom-search my-2 my-sm-0" data-toggle="modal" data-target="#exampleModal""><i class="fas fa-search"></i> Search</button>
    </div> -->
        </div>
      </div> 
    </nav>
<!-- <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form  action="" method="post">
            <div class="input-group mb-3">
                <input type="text" class="form-control" placeholder="Enter keyword here..." aria-label="Enter keywork here..." aria-describedby="basic-addon2">
                <div class="input-group-append">
                    <button class="input-group-text" id="basic-addon2">seach</button>
                </div>
            </div>
        </form>
      </div>
    </div>
  </div>
</div> -->
<a href="#" class="kd-scrollToTop"><i class="custom-scroll-up"></i></a>