
<style type="text/css">
	div.mainpack{
			height: 40vh;
            min-height: 300px;
            background: url('<?=base_url('public/packages/bacolod.jpg');?>') center center no-repeat scroll;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            background-size: cover;
            -o-background-size: cover;
	}
	img.mainpack{
		width: 100%;
	}
	p.pricetag{
		background-color: #ffcc26;
		border-top-right-radius: 15px;
		border-bottom-right-radius: 15px;
		padding-left: 15px;
		padding-top: 2px;
		padding-bottom: 2px;
	}

    @media(max-width: 575px){
    	div.text-right{
    		text-align: left!important;
    	}
      div.container.mainpack{
        padding-right: 0;
        padding-left: 0;
        margin-right: 0;
        margin-left: 0;
      }
    }
    .custom-card{
    	padding:15px;
    }
</style>

  <div class="mainpack mb-3"></div>
<div class="container">
	<div class="row">
		<div class="col-sm-6"><h3>Bacolod Trip / <small>for as low as &#8369;6,000.00</small></h3>
	<p class="text-muted">CITY IN THE PHILIPINES</p></div>
		<!-- <div class="col-md-2"><p class="pricetag font-weight-bold">&#8369;20,000/per pax</p></div> -->
		<div class="col-sm-6 text-right"><p class="text-muted"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i><br><small>OVERALL GUEST RATE</small></p></div>	
	</div>
	<div class="row mt-3">
		<div class="col-lg-8 order-lg-1">
			<div class="">
			<p>Travel period: October 18-22 (23), 2018</p>
<p>
Package inclusions:
- Roundtrip airfare via Cebu Pacific with 15 kilos baggage allowance & Terminal fee
- 4 nights hotel accommodation with daily breakfast
- MEALS and TOURS as per itinerary
- TOURS & TRANSFERS in deluxe coach
- TOUR GUIDE: best english service guide
- Daily bottled water
- Travel Insurance
</p>
<p>
FLIGHT DETAILS:
5J188 Thu, 18OCT MNL-INC 1710-2240
5J187 Mon, 23OCT ICN-MNL 0235-0605
</p>
<p>
As low as 
28,999/ADULT (TWIN SHARING)
34,200/ADULT (SINGLE ROOM)
</p>
<p>
CHILD RATE: 
22,800/CHILD -SHARING BED WITH PARENTS 
25,750/CHILD- EXTRA BED
</p>
<p>
ITINERARY:
Day1 - INCHEON-SEOUL
Arrival at Incheon airport / meet and greet with the guide / transfer to Seoul / hotel check-in
Hotel: Golden City Dongdaemun or Similar 3*
</p>
<p>
Day2 - SEOUL-NAMI ISLAND SEORAK
Transfer to Nami / Nami Island "Shooting place / Pettite France "My Love from the Star" shooting place / transfer to Seorak / hotel check-in / overnight in Seorak (B,L,D)
Hotel: Hyundai Soo Resort or Similar 3*
</p>
<p>
Day3 - SEORAK-YONGIN-SEOUL
Seorak Mountain / Gwongeumsung fortress W lift / Shinheungsa temple / transfer to Yongin / Everland theme park / transfer to Seoul / hotel check-in / overnight in Seoul (B,L,D) 
Hotel: Golden City Dongdaemun or Similar 3*
</p>
<p>
Day4 - SEOUL
Shopping: Cosmetics, Korean ginseng center Nd red pine shop / transfer to gimpo / hyundai cruise with buffer lunch / Hyundai Premium Outlet / transfer back to Seoul / N Seoul Tower w lift (observatory) + love lock (locks excluded) (B,L)
Hotel: Golden City Dongdaemun or Similar 3*
</p>
<p>
Day5 - INCHEON-MANILA
Gyeongbok palace / National Folk Museum / pass by the Blue House / shopping: Amethyst showcase, healthy liver shop and duty free shop / transfer to Incheon for departure / via Korean food and souvenir (B,L)
</p>
<p>
EXCLUSIONS:
~ PH Travel Tax (should be paid to us) - P1620/person
~ tips to the tour guides - USD5/pax/day
~ Visa Processing - P500/person
~ personal expenses
~ beverage during meals
~ other expenses and meals not mentioned in the itinerary
</p>

<p>
GENERAL CONDITIONS:
>FIRST TO RESERVE BASIS
>Travel date(s) are fixed
>Min 2 pax to avail
>Php16,000 Downpayment is non-refundable if due to visa denial 50% or 8000 will be refunded</p>
		</div>
	</div>
		  <div class="pb-3 col-lg-4 order-lg-2">
		  	<div class="card" style="padding:15px;">
          <h4 class="mb-3">Reserve Now!</h4>
          <form class="needs-validation" novalidate>
            <div class="row">
              <div class="col-lg-6 mb-3">
                <label for="firstName">First name</label>
                <input type="text" class="form-control" id="firstName" placeholder="First name" value="" required>
                <div class="invalid-feedback">
                   First name is required.
                </div>
              </div>
              <div class="col-lg-6 mb-3">
                <label for="lastName">Last name</label>
                <input type="text" class="form-control" id="lastName" placeholder="Last name" value="" required>
                <div class="invalid-feedback">
                   Last name is required.
                </div>
              </div>
            </div>
            <div class="mb-3">
              <label for="email">Email Address</label>
              <input type="email" class="form-control" id="email" placeholder="you@example.com" required>
              <div class="invalid-feedback">
                Please enter your email address to receive emails
              </div>
            </div>

            <div class="mb-3">
              <label for="email">Contact Number</label>
              <input type="text" class="form-control" placeholder="Telephone or mobile" required>
              <div class="invalid-feedback">
                Please enter your contact number to contact you
              </div>
            </div>

            <div class="mb-3">
              <label for="travel">Travel Date</label>
              <input type="date" class="form-control" id="travel" required>
              <div class="invalid-feedback">
                Please enter the date of your travel
              </div>
            </div>
             <label for="message">Message</label>
            <div class="mb-3">
              <textarea class="form-control" placeholder="Your message" name="message" id="message" rows="3"></textarea>
              <div class="invalid-feedback">
                Please enter the date of your travel
              </div>
            </div>
            <input type="submit" class="btn btn-success" name="" value="RESERVE TOUR" style="width: 100%;">
            </form>
        </div>
        <div class="mt-4 card custom-card">
        	<h4 class="mb-3">Call Us Today!</h4>
        	<div>Smart: +63 998-566-2561</div>
        	<div>Globe: +63 917-890-2561</div>
        	<div>Sun: +63 922-891-2561</div>
        	<hr>
        	<div class="row">
        	<div class="col-md-6">Monday to Friday:</div>
        	<div class="col-md-6">9:00 AM - 6:00 PM</div>
        	<div class="col-md-6">Saturday & Sunday:</div>
        	<div class="col-md-6">CLOSED</div>
        	</div>
        	
        </div>
        </div>
	</div>
</div>