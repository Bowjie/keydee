<style type="text/css">
	div.mainpack{
            height: 50vh;
            min-height: 300px;
            background: url('<?=base_url('public/packages/boracay.jpg');?>') center center no-repeat scroll;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            background-size: cover;
            -o-background-size: cover;
	}
	img.mainpack{
		width: 100%;
	}
    @media(max-width: 575px){
    	div.text-right{
    		text-align: left!important;
    	}
      div.container.mainpack{
        padding-right: 0;
        padding-left: 0;
        margin-right: 0;
        margin-left: 0;
      }
    }
</style>

  <div class="mainpack mb-3"></div>
<div class="container">
	<div class="row">
		<div class="col-sm-8"><h3>3D2N Boracay Island Package</h3>
      <h5><small><i class="fas fa-bookmark" style="color: #2d64a8;"></i></small> Hotel + Airport Transfers</h5>
      <h6 style="font">(Less P800/PERSON IF WITHOUT TRANSFERS)</h6>
	<p class="text-muted">ISLAND IN PHILIPPINES</p></div>
		<div class="col-sm-4 text-right"><p class="text-muted"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i> 4.5/5<br><small>OVERALL GUEST RATE</small></p>
      <a href="#" class="scrollToDown"><button class="btn btn-primary">Reserve Now!</button></a>
    </div>	
	</div>
  <h6 class="text-center mt-3">Travel Period: Until Dec 15, 2018</h6>
  <div class="table-responsive mt-3">
    <table class="table table-bordered table-sm text-center">
        <tr>
    <th rowspan="3" scope="col" style="vertical-align: middle;">Hotel Name and Location</th>
    <th rowspan="3" scope="col" style="vertical-align: middle;">Category</th>
    <th rowspan="3" scope="col" style="vertical-align: middle;">Travel Dates</th>
    <th colspan="6" scope="col">Published Rate per Person</th>
  </tr>
  <tr>
    <th colspan="3">3D2N Package</th>
    <th colspan="3">Extra Night</th>
  </tr>
    <tr>
    <th>Quad</th>
    <th>Triple</th>
    <th>Twin</th>
    <th>Quad</th>
    <th>Triple</th>
    <th>Twin</th>
  </tr>
  <tr>
    <td rowspan="3" style="vertical-align: middle;"><div>Boracay Travelodge (Stn 2) –</div>
breakfast for 2 only</td>
    <td rowspan="3" style="vertical-align: middle;">2-star</td>
    <td>Jun 1 - Dec 15</td>
    <td>2,050</td>
    <td>2,250</td>
    <td>2,500</td>
    <td>550</td>
    <td>700</td>
    <td>800</td>
  </tr>
  <tr>
    <td>Dec. 16 - May 31</td>
    <td>2,250</td>
    <td>2,500</td>
    <td>2,850</td>
    <td>650</td>
    <td>750</td>
    <td>900</td>
  </tr>
  <tr>
    <td>Festivals, Christmas & New
<div>Year/Chinese New</div>
Year/Holyweek/La Boracay</td>
    <td style="vertical-align: middle;">2,600</td>
    <td style="vertical-align: middle;">2,950</td>
    <td style="vertical-align: middle;">3,450</td>
    <td style="vertical-align: middle;">750</td>
    <td style="vertical-align: middle;">950</td>
    <td style="vertical-align: middle;">1,200</td>
  </tr>
   <tr>
    <td rowspan="3" style="vertical-align: middle;"><div>Island Inn (Stn 2) –</div>breakfast for all</td>
    <td rowspan="3" style="vertical-align: middle;">3-star</td>
    <td>Jun 1 - Nov 30</td>
    <td>2,350</td>
    <td>2,450</td>
    <td>2,650</td>
    <td>600</td>
    <td>650</td>
    <td>800</td>
  </tr>
  <tr>
    <td>Dec. 1 - May 31</td>
    <td>2,450</td>
    <td>2,650</td>
    <td>3,000</td>
    <td>700</td>
    <td>800</td>
    <td>950</td>
  </tr>
  <tr>
    <td>Festivals, Christmas & New
<div>Year/Chinese New</div>
Year/Holyweek/La Boracay</td>
    <td style="vertical-align: middle;">2,700</td>
    <td style="vertical-align: middle;">2,900</td>
    <td style="vertical-align: middle;">3,450</td>
    <td style="vertical-align: middle;">800</td>
    <td style="vertical-align: middle;">900</td>
    <td style="vertical-align: middle;">1,150</td>
  </tr>
  <tr>
    <td rowspan="3" style="vertical-align: middle;"><div>La Carmela de Boracay (Stn 2)</div>beach front - breakfast for 2 only</td>
    <td rowspan="3" style="vertical-align: middle;">3-star</td>
    <td>Jun 1 - Dec 15</td>
    <td>2,500</td>
    <td>2,850</td>
    <td>3,700</td>
    <td>700</td>
    <td>950</td>
    <td>1,300</td>
  </tr>
  <tr>
    <td>Dec 16 - May 31</td>
    <td>2,800</td>
    <td>3,250</td>
    <td>4,300</td>
    <td>900</td>
    <td>1,150</td>
    <td>1,600</td>
  </tr>
  <tr>
    <td>Festivals, Christmas & New
<div>Year/Chinese New</div>
Year/Holyweek/La Boracay</td>
    <td style="vertical-align: middle;">3,050</td>
    <td style="vertical-align: middle;">3,600</td>
    <td style="vertical-align: middle;">4,800</td>
    <td style="vertical-align: middle;">1,050</td>
    <td style="vertical-align: middle;">1,300</td>
    <td style="vertical-align: middle;">1,850</td>
  </tr>
  <tr>
    <td rowspan="2"></td>
    <td colspan="2">Child with bed (w/ bfast)</td>
    <td colspan="3">same as adult</td>
    <td colspan="3">same as adult</td>
  </tr>
  <tr>
    <td colspan="2">Child with bed (w/o bfast)</td>
    <td colspan="3">1,100</td>
    <td colspan="3">0</td>
  </tr>
  <tr>
    <td colspan="9" class="font-weight-bold">OTHER HOTELS ARE ALSO AVAILABLE FOR QUOTATION</td>
  </tr>
    </table>
  </div>
  <div class="mt-4">
  <h5>Package Inclusions</h5>
  <ul>
    <li>3D2N Hotel Accommodation with breakfast</li>
    <li>Round trip Transfers (Kalibo Airport-Hotel-Kalibo Airport) until 6:00pm only</li>
    <p class="font-italic mt-2">[<b>Additional P250/person</b> – surcharge for 6:00pm-10:00pm arrival] – NO TRANSFER WILL PROVIDE FROM 10:00pm-5:59am</p>
  </ul>
</div>
<div class="mt-4">
  <h5 class="d-inline">Exclusion</h5> - Caticlan Terminal Fee (P100/way) and Environmental Fee (P75)
</div>
<div class="mt-4">
  <h5>Itinerary</h5>
  <ul>
    <li>Day 1: Arrival at Kalibo Airport, meet by tour coordinator and take bus (1 hr 30mins travel time) going to caticlan jetty port then take boat going to boracay hotel (30mins travel time) then hotel check-in</li>
    <li>Day 2: Breakfast, free time or join optional tours</li>
    <li>Day 3: Breakfast, hotel check-out, meet and transfer to boat terminal then ride boat going to caticlan jetty port (30 mins travel time) then take bus going back to Kalibo Airport (1 hr 30mins travel time)</li>
  </ul> 
</div>
<div class="mt-4 mb-5">
  <h5 class="text-danger font-weight-bold">Important Note:</h5>
  <ul>
    <li>Room rate is based on cheapest room category hotel check-in is 2:00pm and check-out is 12:00pm. Rate is subject to change without prior notice.</li>
  </ul>
</div>
<div class="table-responsive">
  <table class="table table-bordered table-sm text-center">
    <tr>
      <th>OPTIONAL ITEMS / TOURS per person rate</th>
      <th>Above 7 yrs old</th>
      <th>Below 7 yrs old</th>
    </tr>
    <tr>
      <td>Round Trip Transfer (Kalibo-Hotel-Kalibo)</td>
      <td>1050</td>
      <td>850</td>
    </tr>
    <tr>
      <td>Round Trip Transfer (Caticlan-Hotel-Caticlan)</td>
      <td>910</td>
      <td>800</td>
    </tr>
    <tr>
      <td>Banana Boat Ride 15mins (min 5 pax)</td>
      <td>700</td>
      <td>700</td>
    </tr>
    <tr>
      <td>Paraw Sailing (Joiner) - 35mins</td>
      <td>800</td>
      <td>800</td>
    </tr>
    <tr>
      <td>Island Hopping with lunch (Joiner) – 5-6 hrs.</td>
      <td>1,300</td>
      <td>1,200</td>
    </tr>
    <tr>
      <td>Fly Fish 15mins (min 3 pax)</td>
      <td>950</td>
      <td>950</td>
    </tr>
    <tr>
      <td>Helmet Diving w/ 20mins w/ CD</td>
      <td>1,200</td>
      <td>1,100</td>
    </tr>
    <tr>
      <td>ATV/Buggy Car to Mt. Luho</td>
      <td>1,900</td>
      <td>n/a</td>
    </tr>
    <tr>
      <td>Jetski for 30mins (min 2 pax)</td>
      <td>1,500</td>
      <td>1,500</td>
    </tr>
    <tr>
      <td>Jetski (max. 2pax) – 15mins</td>
      <td>1,900/unit</td>
      <td>1,900/unit</td>
    </tr>
    <tr>
      <td>Parasailing (solo) – 15mins</td>
      <td>2,200</td>
      <td>2,200</td>
    </tr>
    <tr>
      <td>Parasailing (min 2 pax) – 15mins</td>
      <td>1,700</td>
      <td>1,700</td>
    </tr>
    <tr>
      <td>Speedboat (max. 5pax) – 1hr</td>
      <td>5,400/unit</td>
      <td>5,400/unit</td>
    </tr>
    <tr>
      <td>Ariel’s Point (Joiner) – includes lunch, free use of kayak</td>
      <td>2,799</td>
      <td>2,799</td>
    </tr>
    <tr>
      <td>ATV/Go Cart/Zorb Combo</td>
      <td>1,900</td>
      <td>n/a</td>
    </tr>
  </table>
  <span class="font-italic">Note: Optional tours can be booked at least 1 week prior to travel date.</span>
</div>
<h5 class="text-center mt-4 text-danger font-weight-bold">ALL RATES ARE STILL SUBJECT TO CHANGE WITHOUT PRIOR NOTICE</h5>
</div>
<div id="reservenow"></div>
<div class="pt-5 mb-5 pb-5">
<div class="container">
<div class="row">
      <div class="pb-3 col-lg-8">
        <div class="card custom-card">
          <div class="row">
              <div class="col-lg-6"><h4 class="mb-3">Reserve Now!</h4></div>
         </div>
         <div>for as low as:</div><div class="mb-3 text-center bg-light"><sup class="h6" style="font-weight: 400!important;">PHP </sup><span class="h3">2,050.00</span></div>
          <form class="needs-validation" novalidate>
            <div class="row">
              <div class="col-lg-6 mb-3">
                <label for="firstName">First name</label>
                <input type="text" class="form-control" id="firstName" placeholder="First name" value="" required>
                <div class="invalid-feedback">
                   First name is required.
                </div>
              </div>
              <div class="col-lg-6 mb-3">
                <label for="lastName">Last name</label>
                <input type="text" class="form-control" id="lastName" placeholder="Last name" value="" required>
                <div class="invalid-feedback">
                   Last name is required.
                </div>
              </div>
            </div>
            <div class="mb-3">
              <label for="email">Email Address</label>
              <input type="email" class="form-control" id="email" placeholder="you@example.com" required>
              <div class="invalid-feedback">
                Please enter your email address to receive emails
              </div>
            </div>

            <div class="mb-3">
              <label for="email">Contact Number</label>
              <input type="text" class="form-control" placeholder="Telephone or mobile" required>
              <div class="invalid-feedback">
                Please enter your contact number to contact you
              </div>
            </div>

            <div class="mb-3">
              <label for="travel">Travel Date</label>
              <input type="date" class="form-control" id="travel" required>
              <div class="invalid-feedback">
                Please enter the date of your travel
              </div>
            </div>
             <label for="message">Message</label>
            <div class="mb-3">
              <textarea class="form-control" placeholder="Your message" name="message" id="message" rows="3"></textarea>
              <div class="invalid-feedback">
                Please enter the date of your travel
              </div>
            </div>
            <input type="submit" class="btn btn-primary" name="" value="RESERVE TOUR" style="width: 100%;">
            </form>
        </div>
        </div>
        <div class="col-lg-4">
        <div class="card custom-card mb-3">
          <h4 class="mb-3">Call Us Today!</h4>
          <div>Smart: +63 998-566-2561</div>
          <div>Globe: +63 917-890-2561</div>
          <div>Sun: +63 922-891-2561</div>
          <hr>
          <div class="row">
          <div class="col-md-6">Monday to Friday:</div>
          <div class="col-md-6">9:00 AM - 6:00 PM</div>
          <div class="col-md-6">Saturday & Sunday:</div>
          <div class="col-md-6">CLOSED</div>
          </div>
        </div>
        <div class="card custom-card">
          <h5 class="text-danger font-weight-bold">Important!</h5>
          <div class="text-center">
            <div class="font-weight-bold">Travel Period:</div>
            <div>Until December 15, 2018</div>
            <hr>
            <div class="mt-2 font-weight-bold">Exceptional Days:</div>
            <div>Dec. 21, 2018 - Jan. 4, 2019 Christmas Season, Chinese New Year, and Holidays</div>
          </div>
        </div>
        </div>
  </div>

<div class="card mt-4">
  <div class="card-body">
    <blockquote class="blockquote">
      <p>Booking Procedure:</p>
    </blockquote>
    <div class="row">
      <div class="col-lg-12">
        <p class="text-justify">1. Kindly complete the information below and email to <span class="text-primary">smbtravel.ihrell@gmail.com</span> or <span class="text-primary">smbtravel.shiena@gmail.com</span> or <span class="text-primary">smbtravel.erwin@gmail.com</span> to check availability of your booking</p>
      </div>
      <div class="col-lg-5">
        <ul>
          <li>Lead Name or Contact Person: eg. Juan Dela Cruz</li>
          <li>Travel dates: Mar 23 – 25, 2018</li>
          <li>Preferred Hotel: Solaris Hotel Kuta</li>
          <li>Room type: Twin Sharing x 1</li>
        </ul>
      </div>
      <div class="col-lg-7">
        <ul>
          <li>No of adults and child: eg. 2 adults and 1 child</li>
          <li>Flight details (Estimated Time of Arrival and Estimated Time of Departure): ETA is 7:05am via 5J563 &amp;ETD is 5:30pm via 5J584</li>
          <li>Mobile Number: eg. 0999-888-4444</li>
        </ul>
      </div>
      <div class="col-lg-12">
        <p class="text-justify">2. It is advisable to book 1 month prior to travel date. Once reserved, you may settle your payment to SMB bank accounts.</p>
      </div>
      <div class="col-lg-12">
        <div class="table-responsive">
          <table class="table table-bordered table-sm">
            <tr>
              <th class="bg-white"></th>
              <th class="text-center">BPI Savings Bank</th>
              <th class="text-center">Metrobank Current Account</th>
              <th class="text-center">BDO Savings Account</th>
            </tr>
            <tr>
              <td>Account Name</td>
              <td class="text-center">KD Travel and Tours</td>
              <td class="text-center">KD Travel and Tours</td>
              <td class="text-center">KD Travel and Tours</td>
            </tr>
            <tr>
              <td>Account Number</td>
              <td class="text-center">2379-0436-77 for Bank Deposit or Fund Transfer
                <div class="mt-3">2379-0436-75 Jai is 12 for
ATM deposit</div>
              </td>
              <td class="text-center">549-7549-0015-36</td>
              <td class="text-center">00-4610-0859-52</td>
            </tr>
            <tr>
              <td>Branch</td>
              <td class="text-center">Makati Salcedo-Alfaro</td>
              <td class="text-center">Fort One World Place</td>
              <td class="text-center">Quezon Institute</td>
            </tr>
          </table>
        </div>
      </div>
      <div class="col-lg-12">
        <p>3. After payment, immediately forward the PROOF OF PAYMENT or the DEPOSIT SLIP for verification.</p>
      </div>
      <div class="col-lg-12">
        <p>4. After verification, we will finalize your booking. Your tour voucher or booking confirmation will be sent within 2 working days.</p>
      </div>
    </div>
  </div>
</div> 
</div>
</div>