<style type="text/css">
	div.mainpack{
			height: 50vh;
            min-height: 300px;
            background: url('<?=base_url('public/packages/batanes.jpg');?>') center center no-repeat scroll;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            background-size: cover;
            -o-background-size: cover;
	}
	img.mainpack{
		width: 100%;
	}
    @media(max-width: 575px){
    	div.text-right{
    		text-align: left!important;
    	}
      div.container.mainpack{
        padding-right: 0;
        padding-left: 0;
        margin-right: 0;
        margin-left: 0;
      }
    }
</style>

  <div class=" mainpack mb-3"></div>
<div class="container">
	<div class="row">
		<div class="col-sm-8"><h3>3D2N Batanes Rates - Land Arrangement Only</h3>
      <h5><small><i class="fas fa-bookmark" style="color: #2d64a8;"></i></small> Hotel + Airport Transfers</h5>
	<p class="text-muted">CAPITAL OF BASCO, PHILIPPINES</p></div>
		<div class="col-sm-4 text-right"><p class="text-muted"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i> 4.5/5<br><small>OVERALL GUEST RATE</small></p>
      <a href="#" class="scrollToDown"><button class="btn btn-primary">Reserve Now!</button></a>
    </div>	
	</div>
  <h6 class="text-center mt-3">Travel Period: Until Dec 2018</h6>
    <div class="table-responsive mt-3">
   <table class="table  table-bordered table-sm text-center">
    <tr>
    <th rowspan="3" scope="col" style="vertical-align: middle;">Hotel Name</th>
    <th rowspan="3" scope="col" style="vertical-align: middle;">Category</th>
    <th rowspan="3" scope="col" style="vertical-align: middle;">Travel Dates</th>
    <th colspan="6" scope="col">Published Rate per Person</th>
  </tr>
  <tr>
    <th colspan="3">3D2N Package</th>
    <th colspan="3">Extra Night</th>
  </tr>
    <tr>
    <th>Quad</th>
    <th>Triple</th>
    <th>Twin</th>
    <th>Quad</th>
    <th>Triple</th>
    <th>Twin</th>
  </tr>
  <tr>
    <td>Nanay Cita's Homestay</td>
    <td>1-star</td>
    <td>Until Dec 2018</td>
    <td>1,750</td>
    <td>1,950</td>
    <td>2,250</td>
    <td>700</td>
    <td>850</td>
    <td>1,000</td>
  </tr>
  <tr>
    <td>Casa Feliciano</td>
    <td>2-star</td>
    <td>Until June</td>
    <td>2,100</td>
    <td>2,300</td>
    <td>2,500</td>
    <td>900</td>
    <td>1,000</td>
    <td>1,100</td>
  </tr>
  <tr>
    <td>Tawsen’s Place Inn</td>
    <td>2-star</td>
    <td>Oct 2017 – Jun 2018</td>
    <td>2,550</td>
    <td>2,750</td>
    <td>2,850</td>
    <td>1,050</td>
    <td>1,200</td>
    <td>1,300</td>
  </tr>
  <tr>
    <td>Brandon’s Lodge</td>
    <td >2-star</td>
    <td >Until Dec 2018</td>
    <td >2,100</td>
    <td >2,500</td>
    <td >2,900</td>
    <td >900</td>
    <td >1,050</td>
    <td >1,250</td>
  </tr>
  <tr>
    <td>DDD Habitat</td>
    <td>1-star</td>
    <td>Until Dec 2018</td>
    <td>2,300</td>
    <td>2,600</td>
    <td>3,000</td>
    <td>950</td>
    <td>1,100</td>
    <td>1,300</td>
  </tr>
  <tr>
    <td>Batanes Seaside Lodge</td>
    <td>2-star</td>
    <td>Until Dec 2018</td>
    <td>2,400</td>
    <td>2,700</td>
    <td>3,100</td>
    <td>950</td>
    <td>1,100</td>
    <td>1,300</td>
  </tr>
  <tr>
    <td>Midtown Inn</td>
    <td>2-star</td>
    <td>Until Dec 2018</td>
    <td>2,300</td>
    <td>2,600</td>
    <td>3,000</td>
    <td>950</td>
    <td>1,100</td>
    <td>1,300</td>
  </tr>
  <tr>
    <td rowspan="2" style="vertical-align: middle;">Amboy Hometel</td>
    <td rowspan="2" style="vertical-align: middle;">3-star</td>
    <td>Until Nov 2018</td>
    <td>2,750</td>
    <td>2,750</td>
    <td>3,250</td>
    <td>1,300</td>
    <td>1,350</td>
    <td>1,500</td>
  </tr>
  <tr>
    <td>Dec 2017 – Jun 2018</td>
    <td>3,100</td>
    <td>3,300</td>
    <td>3,650</td>
    <td>1,450</td>
    <td>1,500</td>
    <td>1,700</td>
  </tr>
  <tr>
    <td >Bernardos Hotel</td>
    <td >3-star</td>
    <td>Until Dec 2018</td>
    <td>3,100</td>
    <td>3,400</td>
    <td>3,750</td>
    <td>1,250</td>
    <td>1,400</td>
    <td>1,750</td>
  </tr>
  <tr>
    <td></td>
    <td colspan="2">Child with bed (w/ bfast)</td>
    <td colspan="3">same as adult</td>
    <td colspan="3">same as adult</td>
  </tr>
  <tr>
    <td></td>
    <td colspan="2">Child no bed (w/o bfast)</td>
    <td colspan="3">1,150</td>
    <td colspan="3">0</td>
  </tr>
  <tr>
    <td colspan="9" class="font-weight-bold">OTHER HOTELS ARE ALSO AVAILABLE FOR QUOTATION</td>
  </tr>
</table>
</div>
 <div class="mt-4">
  <h5>Package Inclusions</h5>
  <ul>
    <li>3D2N Hotel Accommodation with daily breakfast</li>
    <li>Round trip Transfers (BSO Airport – Hotel – BSO Airport)</li>
  </ul>
</div>
<div class="mt-4">
  <h5>Itinerary</h5>
  <ul>
    <li>Day 1: Arrival at Basco Airport, meet by tour coordinator then transfer to hotel for check-in</li>
    <li>Day 2: Breakfast, free time or join optional tours</li>
    <li>Day 3: Breakfast, hotel check-out, transfer to airport for return flight</li>
  </ul>
</div>
<div class="mt-4 mb-5">
  <h5 class="text-danger font-weight-bold">Important Note:</h5>
  <ul>
    <li>Room rate is based on cheapest room category hotel check-in is 2:00pm and check-out is 12:00pm</li>
  </ul>
</div>
<div class="table-responsive">
  <table class="table table-bordered table-sm text-center">
     <tr>
       <th>OPTIONAL TOURS per person rate</th>
       <th>Min 6 pax (Van)</th>
       <th>Min 4 pax (Van)</th>
       <th>Min 3 pax (VAN)</th>
       <th>Min 2 pax (Tricycle)</th>
     </tr>
     <tr>
       <td>North Batan Tour</td>
       <td>1,400</td>
       <td>1,500</td>
       <td>2,000</td>
       <td>1,300</td>
     </tr>
     <tr>
       <td>South Batan Tour</td>
       <td>1,500</td>
       <td>1,800</td>
       <td>2,100</td>
       <td>1,500</td>
     </tr>
     <tr>
       <td>North and South Batan Tour</td>
       <td>2,300</td>
       <td>2,500</td>
       <td>2,800</td>
       <td>2,500</td>
     </tr>
     <tr>
       <td>Sabtang Tour including boat</td>
       <td>1,900</td>
       <td>2,200</td>
       <td>2,500</td>
       <td>1,800</td>
     </tr>
     <tr>
       <td colspan="5">Note: All tours are assisted only and inclusive of entrance and env't fees
       <div>Add P1,200/tour for a DOT Tour guide (min. 3 pax will require DOT guide)</div></td>
     </tr>
  </table>
  <span class="font-italic">Note: Optional tours can be booked at least 3 weeks prior to travel date except from July – November</span>
</div>
 <h5 class="text-center mt-4 mb-5 text-danger font-weight-bold">ALL RATES ARE STILL SUBJECT TO CHANGE WITHOUT PRIOR NOTICE</h5>
  <div class="card mt-5">
  <h5 class="card-header text-center">Tour Descriptions</h5>
  <div class="card-body" >
    <div class="row">
  <div class="col-md-3 text-right mb-3">North Batan Tour</div>
  <div class="col-md-9 mb-3">
    <ul>
      <li>Fundacion Pacita</li>
      <li>Idjang Viewing, Japanese Hide Out</li>
      <li>Valugan Boulder Beach</li>
      <li>Vayang Rolling Hills</li>
      <li>Light House</li>
      <li>Sto Domingo Church</li>
    </ul>
  </div>
  <div class="col-sm-12"><hr></div>
  <div class="col-md-3 text-right">South Batan Tour</div>
  <div class="col-md-4">
    <ul>
      <li>Chawa Viewdeck</li>
      <li>Shelter Port</li>
      <li>Mahatao Town</li>
      <li>San Jose Borromeo Church</li>
      <li>Marlboro Country</li>
      <li>Old Naval Base</li>
      <li>Alapad</li>
      <li>Song Song Ruins</li>
    </ul>
  </div>
  <div class="col-md-5">
    <ul>
      <li>Ivana Church</li>
      <li>Honesty Coffee Shop and Oldest House</li>
      <li>Mt. Carmel Chapel</li>
      <li>Fortress</li>
      <li>Vernacular Houses</li>
      <li>Tinyan</li>
      <li>Nakabuang Beach</li>
      <li>Siesta and Swimming</li>
    </ul>
  </div>
</div>  
  </div>
</div>
</div>
<div id="reservenow"></div>
<div class="pt-5 mb-5 pb-5">
<div class="container">
<div class="row">
          <div class="pb-3 col-lg-8">
            <div class="card custom-card">
          <div class="row">
              <div class="col-lg-6"><h4 class="mb-3">Reserve Now!</h4></div>
         </div>
         <div>for as low as:</div><div class="mb-3 text-center bg-light"><sup class="h6" style="font-weight: 400!important;">PHP </sup><span class="h3">1,750.00</span></div>
          <form class="needs-validation" novalidate>
            <div class="row">
              <div class="col-lg-6 mb-3">
                <label for="firstName">First name</label>
                <input type="text" class="form-control" id="firstName" placeholder="First name" value="" required>
                <div class="invalid-feedback">
                   First name is required.
                </div>
              </div>
              <div class="col-lg-6 mb-3">
                <label for="lastName">Last name</label>
                <input type="text" class="form-control" id="lastName" placeholder="Last name" value="" required>
                <div class="invalid-feedback">
                   Last name is required.
                </div>
              </div>
            </div>
            <div class="mb-3">
              <label for="email">Email Address</label>
              <input type="email" class="form-control" id="email" placeholder="you@example.com" required>
              <div class="invalid-feedback">
                Please enter your email address to receive emails
              </div>
            </div>

            <div class="mb-3">
              <label for="email">Contact Number</label>
              <input type="text" class="form-control" placeholder="Telephone or mobile" required>
              <div class="invalid-feedback">
                Please enter your contact number to contact you
              </div>
            </div>

            <div class="mb-3">
              <label for="travel">Travel Date</label>
              <input type="date" class="form-control" id="travel" required>
              <div class="invalid-feedback">
                Please enter the date of your travel
              </div>
            </div>
             <label for="message">Message</label>
            <div class="mb-3">
              <textarea class="form-control" placeholder="Your message" name="message" id="message" rows="3"></textarea>
              <div class="invalid-feedback">
                Please enter the date of your travel
              </div>
            </div>
            <input type="submit" class="btn btn-primary" name="" value="RESERVE TOUR" style="width: 100%;">
            </form>
        </div>
        </div>
        <div class="col-lg-4">
        <div class="card custom-card mb-3">
          <h4 class="mb-3">Call Us Today!</h4>
          <div>Smart: +63 998-566-2561</div>
          <div>Globe: +63 917-890-2561</div>
          <div>Sun: +63 922-891-2561</div>
          <hr>
          <div class="row">
          <div class="col-md-6">Monday to Friday:</div>
          <div class="col-md-6">9:00 AM - 6:00 PM</div>
          <div class="col-md-6">Saturday & Sunday:</div>
          <div class="col-md-6">CLOSED</div>
          </div>
        </div>
        <div class="card custom-card">
          <h5 class="text-danger font-weight-bold">Important!</h5>
          <div class="text-center">
            <div class="font-weight-bold">Travel Period Period:</div>
            <div>Until December 2018</div>
            <hr>
            <div class="mt-2 font-weight-bold">Exceptional Days:</div>
            <div>Except Super Peak Dates</div>
          </div>
        </div>
        </div>
    </div>

<div class="card mt-4">
  <div class="card-body">
    <blockquote class="blockquote">
      <p>Booking Procedure:</p>
    </blockquote>
    <div class="row">
      <div class="col-lg-12">
        <p class="text-justify">1. Kindly complete the information below and email to <span class="text-primary">smbtravel.ihrell@gmail.com</span> or <span class="text-primary">smbtravel.shiena@gmail.com</span> or <span class="text-primary">smbtravel.erwin@gmail.com</span> to check availability of your booking</p>
      </div>
      <div class="col-lg-5">
        <ul>
          <li>Lead Name or Contact Person: eg. Juan Dela Cruz</li>
          <li>Travel dates: Mar 23 – 25, 2018</li>
          <li>Preferred Hotel: Solaris Hotel Kuta</li>
          <li>Room type: Twin Sharing x 1</li>
        </ul>
      </div>
      <div class="col-lg-7">
        <ul>
          <li>No of adults and child: eg. 2 adults and 1 child</li>
          <li>Flight details (Estimated Time of Arrival and Estimated Time of Departure): ETA is 7:05am via 5J563 &amp;ETD is 5:30pm via 5J584</li>
          <li>Mobile Number: eg. 0999-888-4444</li>
        </ul>
      </div>
      <div class="col-lg-12">
        <p class="text-justify">2. It is advisable to book 1 month prior to travel date. Once reserved, you may settle your payment to SMB bank accounts.</p>
      </div>
      <div class="col-lg-12">
        <div class="table-responsive">
          <table class="table table-bordered table-sm">
            <tr>
              <th class="bg-white"></th>
              <th class="text-center">BPI Savings Bank</th>
              <th class="text-center">Metrobank Current Account</th>
              <th class="text-center">BDO Savings Account</th>
            </tr>
            <tr>
              <td>Account Name</td>
              <td class="text-center">KD Travel and Tours</td>
              <td class="text-center">KD Travel and Tours</td>
              <td class="text-center">KD Travel and Tours</td>
            </tr>
            <tr>
              <td>Account Number</td>
              <td class="text-center">2379-0436-77 for Bank Deposit or Fund Transfer
                <div class="mt-3">2379-0436-75 Jai is 12 for
ATM deposit</div>
              </td>
              <td class="text-center">549-7549-0015-36</td>
              <td class="text-center">00-4610-0859-52</td>
            </tr>
            <tr>
              <td>Branch</td>
              <td class="text-center">Makati Salcedo-Alfaro</td>
              <td class="text-center">Fort One World Place</td>
              <td class="text-center">Quezon Institute</td>
            </tr>
          </table>
        </div>
      </div>
      <div class="col-lg-12">
        <p>3. After payment, immediately forward the PROOF OF PAYMENT or the DEPOSIT SLIP for verification.</p>
      </div>
      <div class="col-lg-12">
        <p>4. After verification, we will finalize your booking. Your tour voucher or booking confirmation will be sent within 2 working days.</p>
      </div>
    </div>
  </div>
</div> 
</div>
</div>