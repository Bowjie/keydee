<div class="container mt-6 mb-6">
    <div class="row">
        <div class="col-md-9">
            <div class="mb-3">     
            </div>
            <div class="row">
            <?php 
            if($getThai->num_rows() > 0)
            {
                foreach ($getThai->result() as $row) {
            ?>
                <div class="col-md-6 col-sm-6 mb-4">
                    <div class="package-design">
                        <a href="<?=site_url('packages/thailand/'.$row->filename);?>" class="no_design">
                        <div class="most_visited_image">
                                <img class="img-fluid" src="<?=base_url($row->pack_img) ?>" alt=""> 
                            <div class="home_package_price text-white">&#8369; <?=$row->pack_price; ?></div>
                        </div>
                        <div class="card-body bg-white">
                            <div class="custom-all-titles-noHeight"><?=$row->pack_name; ?></div>
                            <small class="text-muted"><?=$row->pack_country; ?></small>
                            <div class="text-muted"></div>
                        </div>
                    </a>
                    </div>
                </div>
            <?php
            }
            }
            ?> 
            </div>
        </div>
        <div class="col-md-3">
            <div class="categories mb-3">
                <h3 class="mb-3">Categories</h3>
                <li><a href="<?=site_url('packages/philippines');?>">Philippines<span>(10)</span></a></li>
                <li><a href="">Tokyo, Japan<span>(10)</span></a></li>
                <li><a href="">China<span>(10)</span></a></li>
                <li><a href="">Singapore<span>(10)</span></a></li>
                <li><a href="<?=site_url('packages/thailand');?>">Indonesia<span>(10)</span></a></li>
                <li class="active"><a class="active2" href="<?=site_url('packages/thailand');?>">Thailand<span>(10)</span></a></li>
            </div>
        </div>
    </div>
</div>
        