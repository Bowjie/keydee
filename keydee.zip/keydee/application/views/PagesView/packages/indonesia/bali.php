<style type="text/css">
	div.mainpack{
			height: 40vh;
            min-height: 300px;
            background: url('<?=base_url('public/packages/bali.jpg');?>') center center no-repeat scroll;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            background-size: cover;
            -o-background-size: cover;
	}
	img.mainpack{
		width: 100%;
	}
    @media(max-width: 575px){
    	div.text-right{
    		text-align: left!important;
    	}
      div.container.mainpack{
        padding-right: 0;
        padding-left: 0;
        margin-right: 0;
        margin-left: 0;
      }
    }
</style>

  <div class="container mainpack mb-3"></div>
<div class="container">
	<div class="row">
		<div class="col-sm-8"><h3>3D2N Bali Indonesia Package</h3>
      <h5><small><i class="fas fa-bookmark" style="color: #2d64a8;"></i></small> Hotel + Airport Transfers</h5>
	<p class="text-muted">ISLAND IN INDONESIA</p></div>
		<div class="col-sm-4 text-right"><p class="text-muted"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i> 4.5/5<br><small>OVERALL GUEST RATE</small></p>
      <a href="#" class="scrollToDown"><button class="btn btn-primary">Reserve Now!</button></a>
    </div>	
	</div>
  <h6 class="text-center mt-3">Travel Period: Until Feb. 28, 2019</h6>
    <div class="table-responsive mt-3">
   <table class="table  table-bordered table-sm text-center">
    <tr>
    <th rowspan="2" scope="col" style="vertical-align: middle;">Hotel Name</th>
    <th rowspan="2" scope="col" style="vertical-align: middle;">Travel Dates</th>
    <th colspan="3" scope="col">Published Rate per Person</th>
  </tr>
    <tr>
    <th>3D2N Package (Twin)</th>
    <th>Entension Night</th>
    <th>Child w/o Bed</th>
  </tr>
  <tr>
    <td rowspan="2" style="vertical-align: middle;">Siesta Legian Hotel or
Alea Seminyak Hotel (3*)</td>
    <td>Until Feb 2019</td>
    <td>3,250</td>
    <td>1,075</td>
    <td>2,199</td>
  </tr>
  <tr>
    <td>Surcharge: Dec. 22-Jan. 3</td>
    <td >Add P500/person/night</td>
    <td>$80</td>
    <td>$80</td>
  </tr>
  <tr>
    <td  rowspan="2">Royal Singosari or Grand Villais Hotel
      <div>Seminyak (4*)</div>
    Min. 3nights stay during Dec. 28-Jan. 4</td>
    <td>Until Feb 2019</td>
    <td>3,850</td>
    <td>1,350</td>
    <td>2,199</td>
  </tr>
  <tr>
    <td ><div>Surcharge:</div> Aug. 20-31 / Dec.
24-Jan. 4</td>
    <td style="vertical-align: middle;">Add P500/person/night</td>
    <td ></td>
    <td ></td>
  </tr>
  <tr>
    <td rowspan="2">Kuta Paradiso or similar (5*) –<div>Aug01-31 – Add P750/person/night</div>
Min. 3nights stay during Dec. 28-Jan. 4</td>
    <td>Until Feb 2019</td>
    <td>6,499</td>
    <td>2,699</td>
    <td>2,550</td>
  </tr>
  <tr>
    <td  ><div>Surcharge:</div> Aug. 20-31 / Dec.
24-Jan. 4</td>
    <td style="vertical-align: middle;">Add P1000/person/night</td>
    <td ></td>
    <td ></td>
  </tr>
  <tr>
    <td colspan="5" class="font-weight-bold">OTHER HOTELS AVAILABLE BY REQUEST</td>
  </tr>
  <tr>
    <td colspan="5">
      <div>Note: Additional P700/person for Special Transfers (10:00pm - 7:00am) and P1,000/person for Foreign Passport holders</div>
     <div><strong>Compulsory New Year Eve Dinner</strong> (4* - P2900/person &amp; 5* - P6,600/person)</div>
    </td>
  </tr>
</table>
</div>
<div class="mt-4">
  <h5>Package Inclusions</h5>
  <ul>
    <li>3D2N Hotel Accommodation with daily breakfast</li>
    <li>R/T Airport transfers (8:00am-10:00pm)</li>
  </ul>
</div>
<div class="mt-4">
  <h5>Itinerary</h5>
  <ul>
    <li>Day 1: Arrival, Meet & transfer to hotel</li>
    <li>Day 2: Breakfast, free time or join optional tours</li>
    <li>Day 3: Breakfast, Hotel check-out then transfer to airport for return flight</li>
  </ul>
</div>
<div class="mt-4 mb-5">
  <h5 class="text-danger font-weight-bold">Important Note:</h5>
  <ul>
    <li>Rate is not valid on Holy Week and Indonesian Holidays</li>
    <li>Room rate is based on cheapest room category hotel check-in is 2:00pm and check-out is 12:00pm</li>
    <li>Rate is valid for Filipino passport holders only</li>
  </ul>
</div>
<div class="table-responsive">
  <table class="table table-bordered table-sm text-center">
      <tr>
        <th scope="col">Optional Tour (per person)</th>
        <th scope="col">Adult/Child</th>
      </tr>
      <tr>
        <td class="w-50 text-left">Half day City Tour – (8:30am-11:30am)</td>
        <td>&#x20B1; 1,495</td>
      </tr>
      <tr>
        <td class="text-left">Full Day BESAKIH Tour - (8:00am-6:00pm)</td>
        <td>&#x20B1; 2,265</td>
      </tr>
      <tr>
        <td class="text-left">Full Day EAST BALI Tour – (8:00am-6:00pm)</td>
        <td>&#x20B1; 2,485</td>
      </tr> 
      <tr>
        <td class="text-left">Half Day UBUD Art Village Tour – (8:30am-11:30am)</td>
        <td>&#x20B1; 1,165</td>
      </tr>
      <tr>
        <td class="text-left">Full Day Bedugul Tour – (8:00am-6:00pm)</td>
        <td>&#x20B1; 1,999</td>
      </tr>
      <tr>
        <td class="text-left">Full Day NORTH BALI Tour – (8:00am-6:00pm)</td>
        <td>&#x20B1; 2,375</td>
      </tr>
  </table>
  <span class="font-italic">Note: Optional tour can arrange 2weeks prior the travel date</span>
</div>
  <h5 class="text-center mt-4 mb-5 text-danger font-weight-bold">ALL RATES/ITINERARY ARE SUBJECT TO CHANGE WITHOUT PRIOR NOTICE</h5>
  <!-- Bootstrap card for tour descriptions -->
 <div class="card mt-5">
  <h5 class="card-header text-center">Tour Descriptions</h5>
  <div class="card-body" >
  <!--   style="max-height: 500px;
    overflow-y: auto;" -->
    <div class="row">
  <div class="col-md-3 text-right mb-3">Half Day Denpasar City Tour</div>
  <div class="col-md-9 mb-3">
    <ul>
      <li>08:30 - Pick Up at hotel's lobby</li>
      <li>JAGATNATHA Temple is Hindu temple in the centre of city</li>
      <li>BADUNG TRADITIONAL Market Is the center activities of seller and buyer with the variety of daily life need</li>
      <li>BAJRA SANDHI Monument is monument located in the heart of town and build to symbolized Balinese people struggle.</li>
    </ul>
  </div>
  <div class="col-sm-12"><hr></div>
  <div class="col-md-3 text-right mb-3">Full Day BEDUGUL Tour</div>
  <div class="col-md-9">
    <ul>
      <li>08:30 Pick Up at hotel&#39;s lobby</li>
      <li>TAMAN AYUN Temple is beautiful temple located in mengwi regency with lake surrounded and beautiful architecture</li>
      <li>COFFEE &amp; SPICES Plantation to watch and taste the balinese coffe and the animal coffe or known as a Luwak Coffee</li>
      <li>LUNCH by Own arrangement</li>
      <li>ULUNDANU Temple in beratan lake, this temple is famous as a tourist destination in north Bali islands</li>
      <li>CANDI KUNING Market for see the traditional vegetable and fruit market, in here also sell some handycraft</li>
    </ul>
  </div>
  <div class="col-sm-12"><hr></div>
  <div class="col-md-3 text-right mb-3">Full Day BESAKIH Tour</div>
  <div class="col-md-9">
    <ul>
      <li>08:30 Pick Up at hotel&#39;s lobby</li>
      <li>KERTA GOSA building is a basis power of Klungkung kingdom long time ago</li>
      <li>BUKIT JAMBUL rice terrace with beautiful panorama of rice paddy</li>
      <li>LUNCH by Own arrangement</li>
      <li>BESAKIH Temple is located in bevel side southwest of Agung Mount and it is consisted of many temples with each temple building owns the</li>
      <li> meaning and function as according to belief of Balinese Hindu.</li>
    </ul>
  </div>
  <div class="col-sm-12" id="showthis"><hr></div>
  <div class="col-md-3 text-right mb-3" id="showthis">Half Day UBUD Art Village Tour</div>
  <div class="col-md-9" id="showthis">
    <ul>
      <li>08:30 Pick Up at hotel&#39;s lobby</li>
      <li>TOHPATI Village for batik textile art</li>
      <li>CELUK Village is a traditional village with famous gold and silver handicraft</li>
      <li>MAS Village for amazing wood carving art</li>
      <li>BATUAN Village is popular with center of Bali painting arts</li>
    </ul>
  </div>
  <div class="col-sm-12" id="showthis"><hr></div>
  <div class="col-md-3 text-right mb-3" id="showthis">Full Day NORTH BALI Tour</div>
  <div class="col-md-9" id="showthis">
    <ul>
      <li>08:30 Pick Up at hotel&#39;s lobby</li>
      <li>TAMAN AYUN Temple is beautiful temple located in mengwi regency with lake surrounded and beautiful architecture</li>
      <li>ULUNDANU Temple is a floating temple in beratan lake</li>
      <li>LUNCH by Own arrangement</li>
      <li>LOVINA BEACH is beautiful beach with black sand along the coast in Northern Bali island</li>
      <li>BANJAR Hot Water Spring hot water from the mountain flows to the public bath place</li>
    </ul>
  </div>
  <div class="col-sm-12" id="showthis"><hr></div>
  <div class="col-md-3 text-right mb-3" id="showthis">Full Day EAST BALI Tour</div>
  <div class="col-md-9" id="showthis">
    <ul>
      <li>08:30 Pick Up at hotel&#39;s lobby</li>
      <li>GOA LAWAH Temple is a Balinese Hindu cave temple where thousands of bats have a nest inside of this cave</li>
      <li>TENGANAN Village Is a traditional Balinese country side with unique cultures and social life LUNCH by Own arrangement</li>
      <li>UJUNG Water Palace Is beautiful garden with fish pond surrounding the old building that is one of Karangasem Empire&#39;s omissions</li>
      <li>TIRTA GANGGA is a beautiful garden with water fountain and fish pond surrounds</li>
    </ul>
  </div>
  </div>
</div>
</div>
<!-- End of Bootstrap card for tour descriptions -->
</div>
<div id="reservenow"></div>
<div class="pt-5 mb-5 pb-5">
<div class="container">
<div class="row">
		  <div class="pb-3 col-lg-8">
		  	<div class="card custom-card">
          <div class="row">
              <div class="col-lg-6"><h4 class="mb-3">Reserve Now!</h4></div>
         </div>
         <div>for as low as:</div><div class="mb-3 text-center bg-light"><sup class="h6" style="font-weight: 400!important;">PHP </sup><span class="h3">3,250.00</span></div>
          <form class="needs-validation" novalidate>
            <div class="row">
              <div class="col-lg-6 mb-3">
                <label for="firstName">First name</label>
                <input type="text" class="form-control" id="firstName" placeholder="First name" value="" required>
                <div class="invalid-feedback">
                   First name is required.
                </div>
              </div>
              <div class="col-lg-6 mb-3">
                <label for="lastName">Last name</label>
                <input type="text" class="form-control" id="lastName" placeholder="Last name" value="" required>
                <div class="invalid-feedback">
                   Last name is required.
                </div>
              </div>
            </div>
            <div class="mb-3">
              <label for="email">Email Address</label>
              <input type="email" class="form-control" id="email" placeholder="you@example.com" required>
              <div class="invalid-feedback">
                Please enter your email address to receive emails
              </div>
            </div>

            <div class="mb-3">
              <label for="email">Contact Number</label>
              <input type="text" class="form-control" placeholder="Telephone or mobile" required>
              <div class="invalid-feedback">
                Please enter your contact number to contact you
              </div>
            </div>

            <div class="mb-3">
              <label for="travel">Travel Date</label>
              <input type="date" class="form-control" id="travel" required>
              <div class="invalid-feedback">
                Please enter the date of your travel
              </div>
            </div>
             <label for="message">Message</label>
            <div class="mb-3">
              <textarea class="form-control" placeholder="Your message" name="message" id="message" rows="3"></textarea>
              <div class="invalid-feedback">
                Please enter the date of your travel
              </div>
            </div>
            <input type="submit" class="btn btn-primary" name="" value="RESERVE TOUR" style="width: 100%;">
            </form>
        </div>
        </div>
        <div class="col-lg-4">
        <div class="card custom-card mb-3">
          <h4 class="mb-3">Call Us Today!</h4>
          <div>Smart: +63 998-566-2561</div>
          <div>Globe: +63 917-890-2561</div>
          <div>Sun: +63 922-891-2561</div>
          <hr>
          <div class="row">
          <div class="col-md-6">Monday to Friday:</div>
          <div class="col-md-6">9:00 AM - 6:00 PM</div>
          <div class="col-md-6">Saturday & Sunday:</div>
          <div class="col-md-6">CLOSED</div>
          </div>
        </div>
        <div class="card custom-card">
          <h5 class="text-danger font-weight-bold">Important!</h5>
          <div class="text-center">
            <div class="font-weight-bold">Travel Period:</div>
            <div>Until February 28, 2019</div>
            <hr>
            <div class="mt-2 font-weight-bold">Exceptional Days:</div>
            <div>Dec. 21, 2018 - Jan. 4, 2019 Christmas Season, Chinese New Year, and Holidays</div>
          </div>
        </div>
        </div>
	</div>

<div class="card mt-4">
  <div class="card-body">
    <blockquote class="blockquote">
      <p>Booking Procedure:</p>
    </blockquote>
    <div class="row">
      <div class="col-lg-12">
        <p class="text-justify">1. Kindly complete the information below and email to <span class="text-primary">smbtravel.ihrell@gmail.com</span> or <span class="text-primary">smbtravel.shiena@gmail.com</span> or <span class="text-primary">smbtravel.erwin@gmail.com</span> to check availability of your booking</p>
      </div>
      <div class="col-lg-5">
        <ul>
          <li>Lead Name or Contact Person: eg. Juan Dela Cruz</li>
          <li>Travel dates: Mar 23 – 25, 2018</li>
          <li>Preferred Hotel: Solaris Hotel Kuta</li>
          <li>Room type: Twin Sharing x 1</li>
        </ul>
      </div>
      <div class="col-lg-7">
        <ul>
          <li>No of adults and child: eg. 2 adults and 1 child</li>
          <li>Flight details (Estimated Time of Arrival and Estimated Time of Departure): ETA is 7:05am via 5J563 &amp;ETD is 5:30pm via 5J584</li>
          <li>Mobile Number: eg. 0999-888-4444</li>
        </ul>
      </div>
      <div class="col-lg-12">
        <p class="text-justify">2. It is advisable to book 1 month prior to travel date. Once reserved, you may settle your payment to SMB bank accounts.</p>
      </div>
      <div class="col-lg-12">
        <div class="table-responsive">
          <table class="table table-bordered table-sm">
            <tr>
              <th class="bg-white"></th>
              <th class="text-center">BPI Savings Bank</th>
              <th class="text-center">Metrobank Current Account</th>
              <th class="text-center">BDO Savings Account</th>
            </tr>
            <tr>
              <td>Account Name</td>
              <td class="text-center">KD Travel and Tours</td>
              <td class="text-center">KD Travel and Tours</td>
              <td class="text-center">KD Travel and Tours</td>
            </tr>
            <tr>
              <td>Account Number</td>
              <td class="text-center">2379-0436-77 for Bank Deposit or Fund Transfer
                <div class="mt-3">2379-0436-75 Jai is 12 for
ATM deposit</div>
              </td>
              <td class="text-center">549-7549-0015-36</td>
              <td class="text-center">00-4610-0859-52</td>
            </tr>
            <tr>
              <td>Branch</td>
              <td class="text-center">Makati Salcedo-Alfaro</td>
              <td class="text-center">Fort One World Place</td>
              <td class="text-center">Quezon Institute</td>
            </tr>
          </table>
        </div>
      </div>
      <div class="col-lg-12">
        <p>3. After payment, immediately forward the PROOF OF PAYMENT or the DEPOSIT SLIP for verification.</p>
      </div>
      <div class="col-lg-12">
        <p>4. After verification, we will finalize your booking. Your tour voucher or booking confirmation will be sent within 2 working days.</p>
      </div>
    </div>
  </div>
</div> 
</div>
</div>