<div class="spinner">
    <h4>NOW LOADING</h4>
  <div class="cube1"></div>
  <div class="cube2"></div>
</div>
<header class="custom_header">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <p class="custom-display-4 text-white mt-auto">Experience The Best Travel With KD</p>
            <p class="custom-display-3 text-white">Reserve Your Favorite Tour Now! <a href=""><button class="btn btn-primary btn-sm">Reserve now!</button></a></p>
        </div>
     </div>
    </div>  
    </header>
    
    <!-- Start packages -->
    <div class="">      
    <div class="container">
        <h2 class="text-center custom-my-3">Most Visited Package</h2>
        <div class="over_line"></div>
        <div class="row">

            <?php 
            if($get_data->num_rows() > 0)
            {
                foreach ($get_data->result() as $row) {
            ?>
                <div class="col-md-4 col-sm-6 mb-4">
                    <div class="package-design">
                        <a href="#" class="no_design">
                        <div class="most_visited_image">
                                <img class="img-fluid" src="<?=base_url($row->kd_img) ?>" alt=""> 
                            <div class="home_package_price text-white">&#8369; <?=$row->kd_price; ?></div>
                        </div>
                        <div class="card-body bg-white">
                            <div class="custom-all-titles-noHeight"><?=$row->kd_name; ?></div>
                            <small class="text-muted"><?=$row->kd_country; ?></small>
                            <div class="text-muted"></div>
                        </div>
                    </a>
                    </div>
                </div>
            <?php
            }
            }
            ?>  
        </div>
        <p class="text-right"><a href="">SEE ALL PACKAGES <i class="fas fa-angle-double-right"></i></a></p>
    </div>
</div>

    <!-- end of carousel  --> 

    <div class="container mb-7">
            <h2 class="text-center custom-my-3">Testimonies</h2>
            <div class="over_line_testimonies"></div>
            <div class="slideshow-container">
<div class="mySlides">
  <q>I love you the more in that I believe you had liked me for my own sake and for nothing else</q>
  <p class="author">- John Keats</p>
</div>

<div class="mySlides">
  <q>But man is not made for defeat. A man can be destroyed but not defeated.</q>
  <p class="author">- Ernest Hemingway</p>
</div>

<div class="mySlides">
  <q>I have not failed. I've just found 10,000 ways that won't work.</q>
  <p class="author">- Thomas A. Edison</p>
</div>

<a class="prev" onclick="plusSlides(-1)">❮</a>
<a class="next" onclick="plusSlides(1)">❯</a>

</div>

<div class="dot-container">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 

</div>
    </div>

    <div style="margin-bottom: 40px;"></div>
    <!-- footer -->
    <div class="container mb-7">
        <h4>Our Airlines</h4>
        <div class="uvsbline mb-3"></div>
    <div class="row">
         <div class="col-md-12">
        <div class="responsive">
          <div>
            <img class="custom_img-fluid" src="<?=base_url('public/airlogo/pal.jpg')?>" alt="" />
          </div>
          <div>
            <img class="custom_img-fluid" src="<?=base_url('public/airlogo/air_china.jpg')?>" alt="" />
          </div>
          <div>
            <img class="custom_img-fluid" src="<?=base_url('public/airlogo/delta.jpg')?>" alt="" />
          </div>
          <div>
            <img class="custom_img-fluid" src="<?=base_url('public/airlogo/korean_air.jpg')?>" alt="">
          </div>
          <div>
            <img class="custom_img-fluid" src="<?=base_url('public/airlogo/air_asia.jpg')?>" alt="" />
          </div>
          <div>
            <img class="custom_img-fluid" src="<?=base_url('public/airlogo/skyjet.jpg')?>" alt="" />
          </div>
          <div>
            <img class="custom_img-fluid" src="<?=base_url('public/airlogo/emirates.jpg')?>" alt="" />
          </div>
          <div>
            <img class="custom_img-fluid" src="<?=base_url('public/airlogo/jetstar.jpg')?>" alt="" />
          </div>
          <div>
            <img class="custom_img-fluid" src="<?=base_url('public/airlogo/singapore_air.jpg')?>" alt="" />
          </div>
          <div>
            <img class="custom_img-fluid" src="<?=base_url('public/airlogo/scoot.jpg')?>" alt="" />
          </div>
          <div>
            <img class="custom_img-fluid" src="<?=base_url('public/airlogo/cathy_pacific.jpg')?>" alt="" />
          </div>
          <div>
            <img class="custom_img-fluid" src="<?=base_url('public/airlogo/cebu_pacific.jpg')?>" alt="" />
          </div>
        </div>
         <!-- control arrows -->
       </div>
    </div>
</div>