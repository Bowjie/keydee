<div class="container">
<h1 class="text-center display-4 linespacing">Travel With Us</h1>
    <p class=" custom-all-titles">Who We Are?</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
</div>

    <div style="margin-bottom: 40px;"></div>
    <div class="container mb-7">
    <p class="custom-all-titles">Our Airlines</p>
    <div class="row">
        <div class="col-md-2 mb-2"><img class="airlogo" src="<?=base_url('public/airlogo/pal.png')?>"></div>
        <div class="col-md-2 mb-2"><img class="airlogo" src="<?=base_url('public/airlogo/air_china.png')?>"></div>
        <div class="col-md-2 mb-2"><img class="airlogo" src="<?=base_url('public/airlogo/delta.png')?>"></div>
        <div class="col-md-2 mb-2"><img class="airlogo" src="<?=base_url('public/airlogo/korean_air.jpg')?>"></div>
        <div class="col-md-2 mb-2"><img class="airlogo" src="<?=base_url('public/airlogo/air_asia.png')?>"></div>
        <div class="col-md-2 mb-2"><img class="airlogo" src="<?=base_url('public/airlogo/skyjet.png')?>"></div>
        <div class="col-md-2 mb-2"><img class="airlogo" src="<?=base_url('public/airlogo/emirates.png')?>"></div>
        <div class="col-md-2 mb-2"><img class="airlogo" src="<?=base_url('public/airlogo/jetstar.png')?>"></div>
        <div class="col-md-2 mb-2"><img class="airlogo" src="<?=base_url('public/airlogo/singapore_air.png')?>"></div>
        <div class="col-md-2 mb-2"><img class="airlogo" src="<?=base_url('public/airlogo/scoot.png')?>"></div>
        <div class="col-md-2 mb-2"><img class="airlogo" src="<?=base_url('public/airlogo/cathy_pacific.png')?>"></div>
        <div class="col-md-2 mb-2"><img class="airlogo" src="<?=base_url('public/airlogo/cebu_pacific.png')?>"></div>
    </div>
</div>