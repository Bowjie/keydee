    <div class="container">
        <h1 class="text-center display-4 linespacing">Contact Us</h1>
        <div class="row mt-3 mb-5">
            <h4 class="col-md-7">Keep In Touch <i class="fas fa-globe-asia fa-spin"></i></h4>
            <div class="col-md-7 mb-3">
                <form action="" method="post">
                <div class="mt-3"><input class="form-control form_contact" placeholder="Your name" type="text" name=""></div>
                <div class="mt-3"><input class="form-control form_contact" placeholder="Your email" type="text" name=""></div>
                <div class="mt-3"><input class="form-control form_contact" placeholder="Your contact number" type="text" name=""></div>
                <div class="mt-3"><textarea class="form-control" placeholder="Message" rows="6"></textarea></div>
                <div class="mt-3">
                    <button type="submit" class="btn btn-primary" style="background: rgb(33, 50, 104);border:rgb(33, 50, 104); padding-left: 30px;padding-right: 30px;">Send</button>
                </div>
            </form>
            </div>
            <div class="col-md-5 mb-5">
                <div class="mt-3 contact-mini-title">Address:</div>
                <div class="mt-2">5 Johnson Drive Pasig City, Metro Manila Philippines</div>
                <div class="mt-3 contact-mini-title">Phones:</div>
                <div class="mt-2">+63 998-566-2561</div>
                <div class="mt-2">+63 922-891-2561</div>
                <div class="mt-2">+63 917-890-2561</div>
                <div class="mt-3 contact-mini-title">Email:</div>
                <div class="mt-2">kdtravelandtour@yahoo.com</div>
                <div class="mt-3 contact-mini-title">Social Media:</div>
                <div class="mt-2">
                    <div class="custom_footer_icons">
                        <ul style="padding:5px;">
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-facebook-messenger"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-yahoo"></i></a></li>
                        </ul>
                        </div>
                </div>
            </div>
            </div>
        <div class="mb-7"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1930.726990545695!2d121.09050094541564!3d14.573188197233392!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397c7c2aeb75509%3A0x75019faf1b7dff06!2sA+Johnson+Dr%2C+Pasig%2C+Metro+Manila!5e0!3m2!1sen!2sph!4v1535379022051" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></div>
        </div>