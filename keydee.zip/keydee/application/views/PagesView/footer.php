<footer class="custom-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-sm-6 mb-2">
                    <div class="row">
                        <div class="col-md-12 mb-3 footer_logo">K <i class="fas fa-map-marker-alt"></i> D Travels & Tours</div>
                        <div class="col-md-12 mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor </div>
                        <div class="col-md-12">
                        <div class="custom_footer_icons">
                        <ul style="padding:5px;">
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-facebook-messenger"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-yahoo"></i></a></li>
                        </ul>
                        </div>
                     </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 mb-2">
                    <div class="row">
                        <div class="col-md-12 mb-3 footer_item">INFORMATION</div>
                        <div class="col-md-12 mb-2">You may contact us via cellphone numbers</div>
                        <div class="col-md-12 mb-2"> +63 998-566-2561</div>
                        <div class="col-md-12 mb-2"> +63 922-891-2561</div>
                        <div class="col-md-12 mb-2"> +63 917-890-2561</div>
                        <div class="col-md-12 mb-2"> <a class="custom-href" href="mailto:kdtravelsandtour@yahoo.com">kdtravelsandtour@yahoo.com</a></div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 mb-2">
                    <div class="row">
                    <div class="col-md-12 mb-3 footer_item">WHAT WE PROVIDE</div>
                    <div class="col-md-12"><i class="fas fa-check"></i> Domestic & International Tickets</div>
                    <div class="col-md-12"><i class="fas fa-check"></i> Hotel Bookings</div>
                    <div class="col-md-12"><i class="fas fa-check"></i> Sight Seeing Tours</div>
                    <div class="col-md-12"><i class="fas fa-check"></i> Tour Packages</div>
                    <div class="col-md-12"><i class="fas fa-check"></i> Land Trip Tours</div>
                    <div class="col-md-12"><i class="fas fa-check"></i> Visa Assistance</div>
                    <div class="col-md-12"><i class="fas fa-check"></i> Travel Insurance</div>
                    </div>
                </div>
                <div class="col-lg-2 col-sm-6 mb-2">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="mb-3 footer_item"><i class="fas fa-certificate" style="color: #e80d0d;"></i> CERTIFIED</div>
                        <div class="cert_dti"><img style="width: 200px;" src="<?=base_url('public/airlogo/dti.png')?>"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <footer class="custom-inner-footer">
        <div class="text-center">Copyright &#169;KD Travels and Tours 2015-2018. All Rights Reserved | Philippines</div>
    </footer>
    <!-- end of footer -->

    <script src="<?=base_url('public/dist/js/jquery-3.3.1.min.js')?>"></script>
    <script src="<?=base_url('public/dist/js/bootstrap.bundle.min.js')?>"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
    <script src="<?=base_url('public/assets/js/kdstyle.js')?>"></script>
    <script src="<?=base_url('public/assets/js/slider.js')?>"></script>
    <script src="<?=base_url('public/assets/js/forms.js')?>"></script>
    <script src="<?=base_url('public/assets/testimonies/testimonies.js')?>"></script>
    <script type="text/javascript">
        $( window ).on('load',(function() {
        $('.spinner').fadeIn('fast').delay(1000).fadeOut('fast');
    }));
    </script>
</body>
</html>