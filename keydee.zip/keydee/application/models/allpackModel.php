<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class allpackModel extends CI_Model
{
	// function getAllPackages{
		
	// }
	function getPhil()
	{
		$this->db->SELECT('*');
		$this->db->FROM('kd_philpack');
		$this->db->ORDER_BY('size, pack_name ASC');
		$query = $this->db->GET();
		return $query;
	}
	function getIndo()
	{
		$this->db->SELECT('*');
		$this->db->FROM('kd_indopack');
		$this->db->ORDER_BY('size, pack_name ASC');
		$query = $this->db->GET();
		return $query;
	}
	function getThai()
	{
		$this->db->SELECT('*');
		$this->db->FROM('kd_thaipack');
		$this->db->ORDER_BY('size, pack_name ASC');
		$query = $this->db->GET();
		return $query;
	}
}