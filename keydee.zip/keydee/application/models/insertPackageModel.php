<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class insertPackageModel extends CI_Model
{
	function insert_package_philippines($data){
		$this->db->insert('kd_philpack', $data);
	}
	function insert_package_china($data){
		$this->db->insert('kd_chinapack', $data);
	}
	function insert_package_taiwan($data){
		$this->db->insert('kd_taiwanpack', $data);
	}
	function insert_package_indonesia($data){
		$this->db->insert('kd_indopack', $data);
	}
	function insert_package_thailand($data){
		$this->db->insert('kd_thaipack', $data);
	}
}