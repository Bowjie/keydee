<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class fetchModel extends CI_Model
{
	function get_data()
	{
		$this->db->select('*');
		$query = $this->db->get('kd_popular_images');
		return $query;
	}
}